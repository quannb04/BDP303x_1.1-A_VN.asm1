class FunixQueue {
  size() {}
}

module.exports = FunixQueue;
