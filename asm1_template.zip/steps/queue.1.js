class FunixQueue {}

module.exports = FunixQueue;
