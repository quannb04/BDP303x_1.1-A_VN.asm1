class FunixQueue {
  elements = [];

  size() {
    return this.elements.length;
  }
}

module.exports = FunixQueue;
